package vn.tien.tienmusic.constant;

import vn.tien.tienmusic.data.model.Song;

public interface ClickListenerItem {
    void onClick(Song song, int position);
}

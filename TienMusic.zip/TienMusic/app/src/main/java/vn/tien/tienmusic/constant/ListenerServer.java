package vn.tien.tienmusic.constant;

public interface ListenerServer {
    void upDateUi();
}

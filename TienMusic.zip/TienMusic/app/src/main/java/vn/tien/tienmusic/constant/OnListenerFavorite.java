package vn.tien.tienmusic.constant;

import vn.tien.tienmusic.data.model.Song;

public interface OnListenerFavorite {
    void listenerClick(Song song);
}

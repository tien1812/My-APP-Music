package vn.tien.tienmusic.constant;

public interface OnListenerItemPlaylist {
    void onClick(int position);
}
